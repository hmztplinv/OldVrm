<?php


return [
    'db' => [
        'name' => 'verim',
        'host' => '94.73.172.240',
        'user' => 'verimdev',
        'pass' => 'ctvH0@694'
    ]
];
