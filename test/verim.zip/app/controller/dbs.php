<?php



require view('dbs');