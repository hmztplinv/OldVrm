<?php

if (!session('user_id')){
    header('Location:'.site_url('login'));
}
require view("hesap_bakiyeleri");