<?php

require view("index");

