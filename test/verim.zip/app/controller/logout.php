<?php

session_destroy();
header("Location:".site_url('login'));