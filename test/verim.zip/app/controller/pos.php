<?php


require view('pos');