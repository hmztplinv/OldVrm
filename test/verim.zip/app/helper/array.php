<?php

$arr = [
"Motor",
"Şanzıman",
"Kaporta",
"Boya",
"Elektrik",
"Beyin",
"Turbo",
"Pompa",
"Ekzoz",
"Lastik & Jant",
"Rot & Balans",
"Çıkma Parça",
"Yedek Parça",
"Karbüratör",
"Klima",
"Radyatör",
"Koltuk Döşeme",
"Yıkama & Temizlik",
"Pasta & Cila",
"Frenci",
"Ateşleme",
"Direksiyon",
"Bakım",
"Air Bag",
"Şaşeci",
"Camcı",
"Akü",
"Ekspertiz",
"Bilye",
"Boyasız Göçük Düzeltme",
"Otogaz",
"Enjektör",
"Dizayn",
"Diferansiyel",
"Sorunu Bilmiyorum"
];

for ($i=0;$i<count($arr);$i++){
  // car::add_problem($arr[$i]);
}
