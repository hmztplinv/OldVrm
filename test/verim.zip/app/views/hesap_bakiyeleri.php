<?php require 'mainPage_statics/header.php'; ?>

    <!-- Container -->
    <div class="container-fluid bg-light pt-5 p-3 small animate__animated animate__fadeIn">

        <ol class="breadcrumb small pt-5">
            <li class="breadcrumb-item text-custom">Hesap Yönetimi</li>
            <li class="breadcrumb-item text-custom"><a href="" class="text-decoration-none text-custom">Hesap Bakiyeleri</a></li>
        </ol>

        <!-- Row 1 -->
        <div class="row pt-2">

            <div class="col-6 col-sm-3 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1"><i class="fa-solid fa-turkish-lira-sign"></i></h6>
                    </header>
                    <div class="card-body">
                        <p class="card-text">
                        <h4 class="text-end text-dark">505.008,00</h4>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-6 col-sm-3 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1"><i class="fa-solid fa-dollar-sign"></i></h6>
                    </header>
                    <div class="card-body">
                        <p class="card-text">
                        <h4 class="text-end text-dark">108.392,00</h4>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-6 col-sm-3 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1"><i class="fa-solid fa-euro-sign"></i></h6>
                    </header>
                    <div class="card-body">
                        <p class="card-text">
                        <h4 class="text-end text-dark">119.286,00</h4>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-6 col-sm-3 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">Toplam</i> (<i class="fa-solid fa-turkish-lira-sign"></i>)</h6>
                    </header>
                    <div class="card-body">
                        <p class="card-text">
                        <h4 class="text-end text-dark">4.383.017,98</h4>
                        </p>
                    </div>
                </div>
            </div>

        </div>
        <!-- Row 1 -->

        <!-- Row 2 -->
        <div class="row pt-2">

            <div class="col-12 col-sm-6 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">Banka Bazında Bakiye Listesi</h6>
                    </header>
                    <div class="card-body">

                        <table id="bankabazindabakiyelistesi" class="display" style="width:100%">
                            <thead>
                            <tr>
                                <th class="text-custom" width="5%"></th>
                                <th class="text-custom" width="15%">Banka</th>
                                <th class="text-custom text-center">TL</th>
                                <th class="text-custom text-center">USD</th>
                                <th class="text-custom text-center">EUR</th>
                                <th class="text-custom text-center">Toplam (TL)</th>
                                <th class="text-custom">Son Güncelleme</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/isbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">159.563,00</td>
                                <td align="center">64.111,00</td>
                                <td align="center">80.990,00</td>
                                <td align="center">2.631.645,77</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/garanti.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">137.835,00</td>
                                <td align="center">15.000,00</td>
                                <td align="center">25.600,00</td>
                                <td align="center">829.889,00</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/ziraat.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">103.642,00</td>
                                <td align="center">29.226,00</td>
                                <td align="center">	12.696,00</td>
                                <td align="center">816.581,86</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/vakifbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">79.365,00</td>
                                <td align="center">0,00</td>
                                <td align="center">0,00</td>
                                <td align="center">79.365,00</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/akbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">24.603,00</td>
                                <td align="center">55,00</td>
                                <td align="center">0,00</td>
                                <td align="center">25.536,35</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 mb-3">
                <div class="card h-100">
                    <div class="card h-100">
                        <header class="card-header d-md-flex align-items-center bg-custom2">
                            <h6 class="card-header-title text-light mt-1">Banka Bazında Bakiye Dağılımı</h6>
                        </header>
                        <div class="card-body">
                            <canvas id="bankChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row 2 -->

        <!-- Row 3 -->
        <div class="row pt-2">

            <div class="col-12 col-sm-6 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">TL Hesap Listesi</h6>
                    </header>
                    <div class="card-body">

                        <table id="tlhesaplistesi" class="display" style="width:100%">
                            <thead>
                            <tr>
                                <th class="text-custom" width="5%"></th>
                                <th class="text-custom" width="15%">Banka</th>
                                <th class="text-custom text-center">Hesap Bakiyesi</th>
                                <th class="text-custom">IBAN</th>
                                <th class="text-custom">Son Güncelleme</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/isbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">138.532,55</td>
                                <td>TR330006277341885261111255</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/garanti.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">137.835,00</td>
                                <td>TR600006248312238265128527</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/vakifbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">79.365,00</td>
                                <td>TR320006236345546148674963</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/ziraat.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">65.220,76</td>
                                <td>TR500006269967432636567958</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/ziraat.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">38.421,24</td>
                                <td>TR300006256813592712638757</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/akbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">24.603,00</td>
                                <td>TR180006277763714566744985</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/isbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">21.030,45</td>
                                <td>TR520006285332354565611184</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">USD Hesap Listesi</h6>
                    </header>
                    <div class="card-body">

                        <table id="usdhesaplistesi" class="display" style="width:100%">
                            <thead>
                            <tr>
                                <th class="text-custom" width="5%"></th>
                                <th class="text-custom" width="15%">Banka</th>
                                <th class="text-custom text-center">Hesap Bakiyesi</th>
                                <th class="text-custom">IBAN</th>
                                <th class="text-custom">Son Güncelleme</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/isbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">64.111,00</td>
                                <td>TR070006251178569192444826</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/ziraat.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">29.226,00</td>
                                <td>TR560006252952441578924869</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/garanti.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">15.000,00</td>
                                <td>TR840006299146763612237346</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
        <!-- Row 3 -->

        <!-- Row 4 -->
        <div class="row pt-2">

            <div class="col-12 col-sm-6 mb-3">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">EUR Hesap Listesi</h6>
                    </header>
                    <div class="card-body">

                        <table id="eurhesaplistesi" class="display" style="width:100%">
                            <thead>
                            <tr>
                                <th class="text-custom" width="5%"></th>
                                <th class="text-custom" width="15%">Banka</th>
                                <th class="text-custom text-center">Hesap Bakiyesi</th>
                                <th class="text-custom">IBAN</th>
                                <th class="text-custom">Son Güncelleme</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/isbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">46.409,80</td>
                                <td>TR280006277547165153444661</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/isbank.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">34.580,20</td>
                                <td>TR230006271949252672365367</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/garanti.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">25.600,00</td>
                                <td>TR130006242119815269641136</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <form action="<?= site_url("hesap_hareketleri")  ?>" method="POST">
                                        <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                        <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                <td align="center"><img class="img-fluid" src="<?=  public_url('img/ziraat.png');  ?>" alt="Banka"></td>
                                </td>
                                <td align="center">12.696,00</td>
                                <td>TR430006218788118378595613</td>
                                <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                            </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

        </div>
        <!-- Row 4 -->


    </div>
    <!-- Container -->


<?php require 'mainPage_statics/footer.php'; ?>
    <script>
        var ctx = document.getElementById("bankChart").getContext("2d");

        var bankChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['İş Bankası', 'Garanti', 'Ziraat', 'VakıfBank', 'Akbank'],
                datasets: [{
                    label: 'TL',
                    backgroundColor: 'rgba(107, 21, 182, 0.8)',
                    data: [159563,137835,103642,79365,24603]
                }, {
                    label: 'USD',
                    backgroundColor: 'rgba(255, 185, 35, 0.8)',
                    data: [64111,15000,29226,0,55]
                }, {
                    label: 'EUR',
                    backgroundColor: 'rgba(255, 87, 86, 0.8)',
                    data: [80990,25600,12696,0,0]
                }]
            },

            options: {
                tooltips: {
                    displayColors: true,
                    callbacks:{
                        mode: 'x',
                    },
                },
                scales: {
                    xAxes: [{
                        stacked: true,
                        gridLines: {
                            display: false,
                        }
                    }],
                    yAxes: [{
                        stacked: true,
                        ticks: {
                            beginAtZero: true,
                        },
                        type: 'linear',
                    }]
                },
                responsive: true,
                maintainAspectRatio: false,
                legend: { position: 'bottom' },
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#bankabazindabakiyelistesi').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'pdf', 'copy', 'print'
                ],
                responsive: {
                    details: false
                },
                pageLength : 5
            });
        })
    </script>
    <script>
        $(document).ready(function() {
            $('#tlhesaplistesi').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'pdf', 'copy', 'print'
                ],
                responsive: {
                    details: false
                },
                pageLength : 5
            });
        })
    </script>
    <script>
        $(document).ready(function() {
            $('#usdhesaplistesi').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'pdf', 'copy', 'print'
                ],
                responsive: {
                    details: false
                },
                pageLength : 5
            });
        })
    </script>
    <script>
        $(document).ready(function() {
            $('#eurhesaplistesi').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'pdf', 'copy', 'print'
                ],
                responsive: {
                    details: false
                },
                pageLength : 5
            });
        })
    </script>
    <script>
        $(document).ready(function() {
            $('#digerhesaplistesi').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'pdf', 'copy', 'print'
                ],
                responsive: {
                    details: false
                },
                pageLength : 5
            });
        })
    </script>

    </body>
    </html>
