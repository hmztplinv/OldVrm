<script src="<?= public_url('js/bootstrap.bundle.min.js') ?>"></script>

<script src="<?= public_url('js/chart.min.js') ?>"></script>

<script src="<?= public_url('js/jquery-3.5.1.js') ?>"></script>
<script src="<?= public_url('js/jquery.dataTables.min.js') ?>"></script>
<script src="<?= public_url('js/dataTables.buttons.min.js') ?>"></script>
<script src="<?= public_url('js/jszip.min.js') ?>"></script>
<script src="<?= public_url('js/pdfmake.min.js') ?>"></script>
<script src="<?= public_url('js/vfs_fonts.js') ?>"></script>
<script src="<?= public_url('js/buttons.html5.min.js') ?>"></script>
<script src="<?= public_url('js/buttons.print.min.js') ?>"></script>

<script src="<?= public_url('js/dataTables.responsive.min.js') ?>"></script>