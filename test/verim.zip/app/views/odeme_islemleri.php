<?php require 'mainPage_statics/header.php' ?>


<!-- Container -->
<div class="container-fluid bg-light pt-5 p-3 small animate__animated animate__fadeIn">

    <ol class="breadcrumb small pt-5">
        <li class="breadcrumb-item text-custom">Hesap Yönetimi</li>
        <li class="breadcrumb-item text-custom"><a href="" class="text-decoration-none text-custom">Ödeme İşlemleri</a></li>
    </ol>

    <!-- Row 1 -->
    <div class="row pt-2">

        <div class="col-12 col-sm-12 mb-3">
            <form action="../../../execution/" method="POST">
                <div class="card h-100">

                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">Ödeme İşlemleri</h6>
                    </header>

                    <div class="card-body">
                        <p class="card-text">

                        <div class="row">

                            <div class="col-12 col-sm-1 p-2">
                                <label class="form-label text-custom"><strong>Banka</strong></label>
                                <select class="form-select small" name="bank">
                                    <option value="" selected disabled>Seçiniz</option>
                                    <option value="">Akbank</option>
                                    <option value="">Alternatif Bank</option>
                                    <option value="">Anadolu Bank</option>
                                    <option value="">Burgan Bank</option>
                                    <option value="">Denizbank</option>
                                    <option value="">Fibabank</option>
                                    <option value="">Garanti BBVA</option>
                                    <option value="">Halk Bank</option>
                                    <option value="">ING</option>
                                    <option value="">İş Bankası</option>
                                    <option value="">Odea</option>
                                    <option value="">QNB Finansbank</option>
                                    <option value="">Şekerbank</option>
                                    <option value="">Ziraat Bankası</option>
                                    <option value="">TEB</option>
                                    <option value="">Vakıfbank</option>
                                    <option value="">Yapı Kredi</option>
                                </select>
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>IBAN</strong></label>
                                <select class="form-select small" name="iban">
                                    <option value="" selected disabled>Seçiniz</option>
                                    <option value="">TR330006277341885261111255</option>
                                    <option value="">TR600006248312238265128527</option>
                                    <option value="">TR320006236345546148674963</option>
                                    <option value="">TR500006269967432636567958</option>
                                    <option value="">TR300006256813592712638757</option>
                                    <option value="">TR180006277763714566744985</option>
                                    <option value="">TR520006285332354565611184</option>
                                    <option value="">TR070006251178569192444826</option>
                                    <option value="">TR560006252952441578924869</option>
                                    <option value="">TR840006299146763612237346</option>
                                    <option value="">TR280006277547165153444661</option>
                                    <option value="">TR230006271949252672365367</option>
                                    <option value="">TR130006242119815269641136</option>
                                    <option value="">TR430006218788118378595613</option>
                                </select>
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Alıcı Adı</strong></label>
                                <input class="form-control small" name="endDate">
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Alıcı IBAN</strong></label>
                                <input class="form-control small" name="endDate">
                            </div>

                            <div class="col-12 col-sm-1 p-2">
                                <label class="form-label text-custom"><strong>Ödeme Tarihi</strong></label>
                                <input class="form-control small" name="startDate" type="date">
                            </div>

                            <div class="col-12 col-sm-1 p-2">
                                <label class="form-label text-custom"><strong>Tutar</strong></label>
                                <input class="form-control small" name="startDate" type="number">
                            </div>

                            <div class="col-12 col-sm-3 p-2">
                                <label class="form-label text-custom"><strong>Açıklama</strong></label>
                                <input class="form-control small" name="familyMemberSurname">
                            </div>

                        </div>
                        </p>
                    </div>

                    <div class="card-footer p-3">
                        <div class="d-grid gap-2 d-md-flex">
                            <button type="button" class="btn btn-sm btn-custom mt-1">Onaya Gönder</button>
                            <button type="button" class="btn btn-sm btn-custom mt-1">Excel Yükle</button>
                        </div>

                    </div>
            </form>
        </div>
    </div>

</div>
<!-- Row 1  -->

</div>
<!-- Container -->


<?php require 'mainPage_statics/footer.php'; ?>


<script>
    $(document).ready(function() {
        $('#hesaphareketilistesi').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'excel', 'pdf', 'copy', 'print'
            ],
            responsive: {
                details: false
            },
            pageLength : 5
        });
    })
</script>

<script>
    function showDiv() {
        document.getElementById('welcomeDiv').style.display = "block";
    }
</script>

</body>
</html>