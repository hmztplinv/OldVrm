<?php require 'mainPage_statics/header.php' ?>


<!-- Container -->
<div class="container-fluid bg-light pt-5 p-3 small animate__animated animate__fadeIn">

    <ol class="breadcrumb small pt-5">
        <li class="breadcrumb-item text-custom">Hesap Yönetimi</li>
        <li class="breadcrumb-item text-custom"><a href="" class="text-decoration-none text-custom">POS</a></li>
    </ol>

    <!-- Row 1 -->
    <div class="row pt-2">

        <div class="col-12 col-sm-6 mb-3">
            <div class="card h-100">
                <header class="card-header d-md-flex align-items-center bg-custom2">
                    <h6 class="card-header-title text-light mt-1">Valör Raporu</h6>
                </header>
                <div class="card-body">

                    <table id="valorraporu" class="display" style="width:100%">
                        <thead>
                        <tr>
                            <th class="text-custom" width="5%"></th>
                            <th class="text-custom text-center" width="15%">Valör Tarihi</th>
                            <th class="text-custom text-center">İşlem Tutarı</th>
                            <th class="text-custom text-center">Komisyon</th>
                            <th class="text-custom text-center">Net Tutar</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td align="center">
                                <form action="../hesap-hareketleri/" method="POST">
                                    <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                    <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </form>
                            <td align="center">2022/Ağustos</td>
                            <td align="center">3.327.846,00</td>
                            <td align="center">33.278,46</td>
                            <td align="center">3.294.567,54</td>
                        </tr>
                        <tr>
                            <td align="center">
                                <form action="../hesap-hareketleri/" method="POST">
                                    <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                    <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </form>
                            <td align="center">2022/Eylül</td>
                            <td align="center">3.029.757,00</td>
                            <td align="center">30.297,57</td>
                            <td align="center">2.999.459,43</td>
                        </tr>
                        <tr>
                            <td align="center">
                                <form action="../hesap-hareketleri/" method="POST">
                                    <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                    <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </form>
                            <td align="center">2022/Ekim</td>
                            <td align="center">1.852.603,00</td>
                            <td align="center">18.526,03</td>
                            <td align="center">1.834.076,97</td>
                        </tr>
                        <tr>
                            <td align="center">
                                <form action="../hesap-hareketleri/" method="POST">
                                    <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                    <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </form>
                            <td align="center">2022/Kasım</td>
                            <td align="center">1.095.039,00</td>
                            <td align="center">10.950,39</td>
                            <td align="center">1.084.088,61</td>
                        </tr>
                        <tr>
                            <td align="center">
                                <form action="../hesap-hareketleri/" method="POST">
                                    <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                    <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </form>
                            <td align="center">2022/Aralık</td>
                            <td align="center">384.578,00</td>
                            <td align="center">3.845,78</td>
                            <td align="center">380.732,22</td>
                        </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 mb-3">
            <div class="card h-100">
                <div class="card h-100">
                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">Banka Bazında Valör</h6>
                    </header>
                    <div class="card-body">
                        <canvas id="bankChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Row 1 -->


    <!-- Row 2 -->
    <div class="row pt-2">

        <div class="col-12 col-sm-12 mb-3">
            <form action="../../../execution/" method="POST">
                <div class="card h-100">

                    <header class="card-header d-md-flex align-items-center bg-custom2">
                        <h6 class="card-header-title text-light mt-1">POS Hareketleri</h6>
                    </header>

                    <div class="card-body">
                        <p class="card-text">

                        <div class="row">

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Banka</strong></label>
                                <select class="form-select small" name="bank">
                                    <option value="" selected disabled>Seçiniz</option>
                                    <option value="">Akbank</option>
                                    <option value="">Alternatif Bank</option>
                                    <option value="">Anadolu Bank</option>
                                    <option value="">Burgan Bank</option>
                                    <option value="">Denizbank</option>
                                    <option value="">Fibabank</option>
                                    <option value="">Garanti BBVA</option>
                                    <option value="">Halk Bank</option>
                                    <option value="">ING</option>
                                    <option value="">İş Bankası</option>
                                    <option value="">Odea</option>
                                    <option value="">QNB Finansbank</option>
                                    <option value="">Şekerbank</option>
                                    <option value="">Ziraat Bankası</option>
                                    <option value="">TEB</option>
                                    <option value="">Vakıfbank</option>
                                    <option value="">Yapı Kredi</option>
                                </select>
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Üye İşyeri</strong></label>
                                <select class="form-select small" name="currency">
                                    <option value="" selected disabled>Seçiniz</option>
                                    <option value="">TL</option>
                                    <option value="">USD</option>
                                    <option value="">EUR</option>
                                </select>
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Başlangıç Tarihi</strong></label>
                                <input class="form-control small" name="startDate" type="date">
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Bitiş Tarihi</strong></label>
                                <input class="form-control small" name="endDate" type="date">
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Başlangıç Tutarı</strong></label>
                                <input class="form-control small" name="startDate" type="number">
                            </div>

                            <div class="col-12 col-sm-2 p-2">
                                <label class="form-label text-custom"><strong>Bitiş Tutarı</strong></label>
                                <input class="form-control small" name="endDate" type="number">
                            </div>

                        </div>
                        </p>
                    </div>

                    <div class="card-footer p-3">
                        <div class="d-grid gap-2 d-md-flex">
                            <button type="button" name="answer" value="Show Div" onclick="showDiv()" class="btn btn-sm btn-custom mt-1">Sorgula</button>

                        </div>
                    </div>
            </form>
        </div>
    </div>

</div>
<!-- Row 2 -->


<!-- Row 3 -->
<div class="row pt-2 animate__animated animate__fadeIn" id="welcomeDiv"  style="display:none;" class="answer_list">

    <div class="col-12 col-sm-12 mb-3">
        <div class="card h-100">
            <header class="card-header d-md-flex align-items-center bg-custom2">
                <h6 class="card-header-title text-light mt-1">POS Hareketleri</h6>
            </header>
            <div class="card-body">

                <table id="poshareketleri" class="display" style="width:100%">
                    <thead>
                    <tr>
                        <th class="text-custom" width="5%"></th>
                        <th class="text-custom" width="7%">Banka</th>
                        <th class="text-custom text-center">Üye İşyeri</th>
                        <th class="text-custom text-center">Terminal</th>
                        <th class="text-custom text-center">Provizyon</th>
                        <th class="text-custom text-center">İşlem Tar.</th>
                        <th class="text-custom text-center">Valör Tar.</th>
                        <th class="text-custom text-center">Tutar</th>
                        <th class="text-custom text-center">Komisyon Oranı</th>
                        <th class="text-custom text-center">Komisyon Tutarı</th>
                        <th class="text-custom text-center">Net Tutar</th>
                        <th class="text-custom text-center">Para Birimi</th>
                        <th class="text-custom text-center">Taksit Sayısı</th>
                        <th class="text-custom text-center">Taksit Sırası</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td align="center">
                            <form action="../hesap-hareketleri/" method="POST">
                                <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        <td align="center"><img class="img-fluid" src="<?= public_url("img/isbank.png")  ?>" alt="Banka"></td>
                        </td>
                        <td align="center">İstinye Park (32143314)</td>
                        <td align="center">6543633</td>
                        <td align="center">97854</td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td align="center">1.250,00</td>
                        <td align="center">1,00</td>
                        <td align="center">12,50</td>
                        <td align="center">1.237,50</td>
                        <td align="center">TL</td>
                        <td align="center">1</td>
                        <td align="center">1</td>
                    </tr>
                    <tr>
                        <td align="center">
                            <form action="../hesap-hareketleri/" method="POST">
                                <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        <td align="center"><img class="img-fluid" src="<?= public_url("img/garanti.png")  ?>" alt="Banka"></td>
                        </td>
                        <td align="center">İstinye Park (32143314)</td>
                        <td align="center">123212</td>
                        <td align="center">97575</td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td align="center">250,00</td>
                        <td align="center">1,00</td>
                        <td align="center">2,50</td>
                        <td align="center">247,50</td>
                        <td align="center">TL</td>
                        <td align="center">1</td>
                        <td align="center">1</td>
                    </tr>
                    <tr>
                        <td align="center">
                            <form action="../hesap-hareketleri/" method="POST">
                                <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        <td align="center"><img class="img-fluid" src="<?= public_url("img/garanti.png")  ?>" alt="Banka"></td>
                        </td>
                        <td align="center">İstinye Park (32143314)</td>
                        <td align="center">123212</td>
                        <td align="center">97543</td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td align="center">50,00</td>
                        <td align="center">1,00</td>
                        <td align="center">0,50</td>
                        <td align="center">49,50</td>
                        <td align="center">TL</td>
                        <td align="center">1</td>
                        <td align="center">1</td>
                    </tr>
                    <tr>
                        <td align="center">
                            <form action="../hesap-hareketleri/" method="POST">
                                <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        <td align="center"><img class="img-fluid" src="<?= public_url("img/akbank.png")  ?>" alt="Banka"></td>
                        </td>
                        <td align="center">Mall of İstanbul (123215)</td>
                        <td align="center">76342</td>
                        <td align="center">44632</td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td align="center">1.500,00</td>
                        <td align="center">1,00</td>
                        <td align="center">15,00</td>
                        <td align="center">1.485,00</td>
                        <td align="center">TL</td>
                        <td align="center">4</td>
                        <td align="center">1</td>
                    </tr>
                    <tr>
                        <td align="center">
                            <form action="../hesap-hareketleri/" method="POST">
                                <input type="hidden" id="iban" name="iban" value="TR323232323232323223232">
                                <button type="submit" class="btn btn-sm btn-outline-custom"formmethod="post"><i class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        <td align="center"><img class="img-fluid" src="<?= public_url("img/vakifbank.png")  ?>" alt="Banka"></td>
                        </td>
                        <td align="center">Cevahir AVM (654321)</td>
                        <td align="center">623121</td>
                        <td align="center">64311</td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td><?php echo date("d/m/y h:i:s", time()); ?></td>
                        <td align="center">750,00</td>
                        <td align="center">1,00</td>
                        <td align="center">7,50</td>
                        <td align="center">742,50</td>
                        <td align="center">TL</td>
                        <td align="center">2</td>
                        <td align="center">1</td>
                    </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<!-- Row 3 -->


</div>
<!-- Container -->


<?php require 'mainPage_statics/footer.php'; ?>

<script>
    function showDiv() {
        document.getElementById('welcomeDiv').style.display = "block";
    }
</script>

<script>
    var ctx = document.getElementById("bankChart").getContext("2d");

    var bankChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['İş Bankası', 'Garanti', 'Ziraat', 'VakıfBank', 'Akbank'],
            datasets: [{
                label: 'Ağustos',
                backgroundColor: 'rgba(107, 21, 182, 0.8)',
                data: [740294,665569,660909,688598,572476]
            }, {
                label: 'Eylül',
                backgroundColor: 'rgba(255, 185, 35, 0.8)',
                data: [675445,634750,598466,613991,507105]
            }, {
                label: 'Ekim',
                backgroundColor: 'rgba(255, 87, 86, 0.8)',
                data: [347910,375261,450013,377494,301925]
            }, {
                label: 'Kasım',
                backgroundColor: 'rgba(114, 211, 220, 0.8)',
                data: [269319,156682,245452,259379,164207]
            }, {
                label: 'Aralık',
                backgroundColor: 'rgba(123, 192, 67, 0.8)',
                data: [69141,86453,92204,51711,85069]
            }]
        },

        options: {
            tooltips: {
                displayColors: true,
                callbacks:{
                    mode: 'x',
                },
            },
            scales: {
                xAxes: [{
                    stacked: true,
                    gridLines: {
                        display: false,
                    }
                }],
                yAxes: [{
                    stacked: true,
                    ticks: {
                        beginAtZero: true,
                    },
                    type: 'linear',
                }]
            },
            responsive: true,
            maintainAspectRatio: false,
            legend: { position: 'bottom' },
        }
    });
</script>
<script>
    $(document).ready(function() {
        $('#valorraporu').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'excel', 'pdf', 'copy', 'print'
            ],
            responsive: {
                details: false
            },
            pageLength : 5
        });
    })
</script>
<script>
    $(document).ready(function() {
        $('#poshareketleri').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'excel', 'pdf', 'copy', 'print'
            ],
            responsive: {
                details: false
            },
            pageLength : 5
        });
    })
</script>

</body>
</html>
